# Ropa E-commerce (sin Spring Security)

- REST con Spring Web
- JPA con Hibernate
- H2 en memoria (default) y perfil MySQL
- Registro y login sin Spring Security (token de sesión en memoria)
- No se muestran productos sin stock por defecto

## Cómo abrir en VS Code
1. Abrí VS Code → File > Open Folder → seleccioná la carpeta `ropa-ecommerce`.
2. En la Terminal integrada:
   ```bash
   mvn clean spring-boot:run
   ```
   App en `http://localhost:4003`. Consola H2 en `http://localhost:4003/h2` (JDBC: `jdbc:h2:mem:ropa`).

### Con MySQL
Editá `src/main/resources/application-mysql.properties` y corré:
```bash
mvn spring-boot:run -Dspring-boot.run.profiles=mysql
```

## Endpoints
- `POST /auth/register`  `{ email, password, fullName }`
- `POST /auth/login`     → `{ token, userId, email, fullName }`
- `GET /auth/me`         (header `X-Auth-Token`)
- `GET /categories` / `POST /categories?name=Remeras`
- `GET /products` (oculta sin stock) / `?includeOutOfStock=true` / `?categoryId=1` / `?q=remera`
- `POST /products`, `PUT /products/{id}`, `DELETE /products/{id}`
