package com.victoria.ropa.repo;

import com.victoria.ropa.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Long> {
    List<Product> findByStockGreaterThan(int stock);
    List<Product> findByCategory_IdAndStockGreaterThan(Long categoryId, int stock);
    List<Product> findByCategory_Id(Long categoryId);
    List<Product> findByNameContainingIgnoreCaseAndStockGreaterThan(String name, int stock);
    List<Product> findByNameContainingIgnoreCase(String name);
}
