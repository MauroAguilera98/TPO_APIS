package com.victoria.ropa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RopaEcommerceApplication {
    public static void main(String[] args) {
        SpringApplication.run(RopaEcommerceApplication.class, args);
    }
}
