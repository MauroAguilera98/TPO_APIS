package com.victoria.ropa.config;

import com.victoria.ropa.model.Category;
import com.victoria.ropa.model.Product;
import com.victoria.ropa.repo.CategoryRepository;
import com.victoria.ropa.repo.ProductRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.math.BigDecimal;

@Configuration
public class DemoDataLoader {

    @Bean
    CommandLineRunner seed(CategoryRepository cats, ProductRepository prods) {
        return args -> {
            if (cats.count() == 0) {
                Category remeras = cats.save(new Category("Remeras"));
                Category pantalones = cats.save(new Category("Pantalones"));
                Category buzos = cats.save(new Category("Buzos"));

                prods.save(new Product("Remera básica", "Algodón peinado", new BigDecimal("9999.00"), 10, remeras));
                prods.save(new Product("Pantalón chino", "Color beige", new BigDecimal("24999.00"), 5, pantalones));
                prods.save(new Product("Buzo oversize", "Con capucha", new BigDecimal("19999.00"), 0, buzos));
            }
        };
    }
}
