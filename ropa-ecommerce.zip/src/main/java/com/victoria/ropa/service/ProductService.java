package com.victoria.ropa.service;

import com.victoria.ropa.dto.CreateProductRequest;
import com.victoria.ropa.dto.ProductResponse;
import com.victoria.ropa.model.Category;
import com.victoria.ropa.model.Product;
import com.victoria.ropa.repo.CategoryRepository;
import com.victoria.ropa.repo.ProductRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductService {
    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;

    public ProductService(ProductRepository productRepository, CategoryRepository categoryRepository) {
        this.productRepository = productRepository;
        this.categoryRepository = categoryRepository;
    }

    @Transactional
    public ProductResponse create(CreateProductRequest req) {
        Category cat = null;
        if (req.getCategoryId() != null) {
            cat = categoryRepository.findById(req.getCategoryId())
                    .orElseThrow(() -> new IllegalArgumentException("Categoría no encontrada"));
        }
        Product p = new Product(req.getName(), req.getDescription(), req.getPrice(), req.getStock(), cat);
        p = productRepository.save(p);
        return toDto(p);
    }

    @Transactional
    public ProductResponse update(Long id, CreateProductRequest req) {
        Product p = productRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Producto no encontrado"));
        p.setName(req.getName());
        p.setDescription(req.getDescription());
        p.setPrice(req.getPrice());
        p.setStock(req.getStock());
        if (req.getCategoryId() != null) {
            Category cat = categoryRepository.findById(req.getCategoryId())
                    .orElseThrow(() -> new IllegalArgumentException("Categoría no encontrada"));
            p.setCategory(cat);
        } else {
            p.setCategory(null);
        }
        p = productRepository.save(p);
        return toDto(p);
    }

    public List<ProductResponse> list(Boolean includeOutOfStock, Long categoryId, String q) {
        boolean include = includeOutOfStock != null && includeOutOfStock;
        List<Product> list;
        if (q != null && !q.isBlank()) {
            list = include ? productRepository.findByNameContainingIgnoreCase(q)
                           : productRepository.findByNameContainingIgnoreCaseAndStockGreaterThan(q, 0);
        } else if (categoryId != null) {
            list = include ? productRepository.findByCategory_Id(categoryId)
                           : productRepository.findByCategory_IdAndStockGreaterThan(categoryId, 0);
        } else {
            list = include ? productRepository.findAll()
                           : productRepository.findByStockGreaterThan(0);
        }
        return list.stream().map(this::toDto).collect(Collectors.toList());
    }

    public ProductResponse get(Long id) {
        Product p = productRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Producto no encontrado"));
        return toDto(p);
    }

    @Transactional
    public void delete(Long id) {
        productRepository.deleteById(id);
    }

    private ProductResponse toDto(Product p) {
        Long catId = p.getCategory() != null ? p.getCategory().getId() : null;
        String catName = p.getCategory() != null ? p.getCategory().getName() : null;
        return new ProductResponse(p.getId(), p.getName(), p.getDescription(), p.getPrice(), p.getStock(), catId, catName);
    }
}
