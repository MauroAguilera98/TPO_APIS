package com.victoria.ropa.service;

import com.victoria.ropa.model.UserEntity;
import com.victoria.ropa.repo.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthService {
    private final UserRepository userRepository;

    public AuthService(UserRepository userRepository) { this.userRepository = userRepository; }

    @Transactional
    public UserEntity register(String email, String password, String fullName) {
        if (userRepository.existsByEmail(email)) throw new IllegalArgumentException("El email ya está registrado");
        return userRepository.save(new UserEntity(email, password, fullName));
    }

    public UserEntity login(String email, String password) {
        return userRepository.findByEmail(email)
                .filter(u -> u.getPassword().equals(password))
                .orElseThrow(() -> new IllegalArgumentException("Credenciales inválidas"));
    }
}
