package com.victoria.ropa.web;

import com.victoria.ropa.dto.LoginRequest;
import com.victoria.ropa.dto.LoginResponse;
import com.victoria.ropa.dto.RegisterRequest;
import com.victoria.ropa.model.UserEntity;
import com.victoria.ropa.service.AuthService;
import com.victoria.ropa.session.SessionStore;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {
    private final AuthService authService;
    private final SessionStore sessionStore;

    public AuthController(AuthService authService, SessionStore sessionStore) {
        this.authService = authService;
        this.sessionStore = sessionStore;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@Validated @RequestBody RegisterRequest req) {
        UserEntity u = authService.register(req.getEmail(), req.getPassword(), req.getFullName());
        return ResponseEntity.ok("Usuario registrado con id=" + u.getId());
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@Validated @RequestBody LoginRequest req) {
        UserEntity u = authService.login(req.getEmail(), req.getPassword());
        String token = sessionStore.createSession(u.getId());
        return ResponseEntity.ok(new LoginResponse(token, u.getId(), u.getEmail(), u.getFullName()));
    }

    @GetMapping("/me")
    public ResponseEntity<?> me(@RequestHeader(name="X-Auth-Token", required=false) String token) {
        if (token == null) return ResponseEntity.status(401).body("No estás logueado");
        Long userId = sessionStore.getUserId(token);
        if (userId == null) return ResponseEntity.status(401).body("Token inválido");
        return ResponseEntity.ok("Estás logueado como userId=" + userId);
    }
}
