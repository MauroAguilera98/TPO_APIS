package com.victoria.ropa.web;

import com.victoria.ropa.model.Category;
import com.victoria.ropa.repo.CategoryRepository;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/categories")
public class CategoryController {

    private final CategoryRepository categoryRepository;

    public CategoryController(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    @GetMapping
    public List<Category> list() {
        return categoryRepository.findAll();
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestParam("name") @NotBlank String name) {
        if (categoryRepository.existsByName(name)) {
            return ResponseEntity.badRequest().body("La categoría ya existe");
        }
        Category c = categoryRepository.save(new Category(name));
        return ResponseEntity.ok(c);
    }
}
